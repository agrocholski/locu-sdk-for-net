﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Resources
{
    public class Keys
    {
        public static string LocuApiKey
        {
            get { return ""; }
        }

        public static string LocuVenueId
        {
            get { return ""; }
        }

        public static string MapsApplicationId
        {
            get { return ""; }
        }

        public static string MapsAuthenticationToken
        {
            get { return ""; }
        }
    }
}
